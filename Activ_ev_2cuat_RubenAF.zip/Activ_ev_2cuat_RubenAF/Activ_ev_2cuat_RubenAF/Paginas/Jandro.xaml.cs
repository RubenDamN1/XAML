﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Activ_ev_2cuat_RubenAF.Paginas
{
    /// <summary>
    /// Lógica de interacción para Jandro.xaml
    /// </summary>
    public partial class Jandro : Page
    {
        public Jandro()
        {
            //InitializeComponent();
        }
    }
}
